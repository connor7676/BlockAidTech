<?php
use SimpleSoftwareIO\QrCode\Facades\QrCode;
?>

@extends('layouts.app')

@section('content')
<br>
<br>
<br>
<div class="container py-5">

    <div class="row justify-content-center pb-5">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Dashboard') }}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    {{ __('You are logged in!') }}
                    <br>
                    <br>
                    {{-- account details --}}
                    <div class="row">
                        <div class="col-md-6">
                            <h3>Account Details</h3>
                            <ul>
                                <li>Name: {{ Auth::user()->name }}</li>
                                <li>Email: {{ Auth::user()->email }}</li>
                                <li>Created At: {{ Auth::user()->created_at }}</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Wallet Address</div>

                <div class="card-body">
                    @if (!is_null(Auth::user()->bitcoin_address))
                        {{-- <div class="alert alert-success" role="alert">
                            {{ __('You have one.') }}
                        </div> --}}
                        <div class="visible-print text-center">
                           {{ QrCode::size(250)->generate(Auth::user()->bitcoin_address); }}
                        </div>
                        <p class="text-center">{{ Auth::user()->bitcoin_address }}</p>
                    @else
                        <div class="alert alert-info" role="alert">
                            {{ __('You have not added a wallet yet.') }}
                        </div>
                        {{-- create form to add wallet address using user id --}}
                        
                            {!! Form::open(['action' => 'App\Http\Controllers\DashboardController@update', 'method' => 'POST']) !!}
                                <div class="form-group py-4">
                                    {{Form::label('bitcoin_address', 'Bitcoin Address')}}
                                    {{Form::text('bitcoin_address', '', ['class' => 'form-control', 'placeholder' => 'Wallet Address'])}}
                                </div>
                                {{Form::submit('Add Wallet', ['class' => 'btn btn-primary'])}}
                            {!! Form::close() !!}
                        

                    @endif
                </div>
            </div>
        </div>
    </div>

    {{-- <div class="panel-body">
        <a href="/posts/create" class="btn btn-primary">Create Posts</a>
        <h3>Your Blog Posts</h3>
        @if(count($posts) > 0)
            <table class="table table-striped">
                @foreach ($posts as $post)
                    <tr>
                        <td>{{$post->title}}</td>
                    </tr>
                @endforeach
            </table>
        @else
            <p>You have no posts</p>
        @endif
    </div> --}}
</div>
@endsection
