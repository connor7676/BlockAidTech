@extends('layouts.app')

@section('content')
    <h1>Base</h1>
@endsection