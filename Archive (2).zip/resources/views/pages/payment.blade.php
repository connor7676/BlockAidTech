@extends('layouts.app')

@section('content')

<br>
<br>
<br>
<br>

<div class="py-5">
    <center>
        <img src="{{ asset('img/payment-screen.png') }}" alt="">
    </center>
</div>

@endsection